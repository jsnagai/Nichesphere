comm module
=======================

Focused on differential communication

.. automodule:: comm
   :members:
   :show-inheritance:
