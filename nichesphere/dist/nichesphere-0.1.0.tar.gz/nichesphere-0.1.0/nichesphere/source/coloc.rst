coloc module
=======================

Focused on differential co-localization

.. automodule:: coloc
   :members:
   :show-inheritance:
