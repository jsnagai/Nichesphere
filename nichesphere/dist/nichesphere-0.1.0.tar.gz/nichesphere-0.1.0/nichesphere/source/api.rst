fake module
=======================

.. automodule:: fake
   :members:
   :undoc-members:
   :show-inheritance:
